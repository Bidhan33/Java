function main() { 
    
    fetch("http://localhost:8080/WebAppExercises/Student")
        // Convert the server's JSON response to a JavaScript object
        .then(response => response.json())     
        
        .then(studentList => printStudent(studentList));        
} 

function printStudent(studentList) { 
    let divOutput = document.getElementById("divOutput");
    let outputText = "";
    
    for (let student of studentList) { 
        outputText += student.firstname + " (" + student.id + ")<br/>"; 
    } 
    
    divOutput.innerHTML = outputText;
}  

// Call the main function when the browser loads the HTML page
main();
